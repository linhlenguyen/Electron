const fs = require('fs')

function loadDir(filedir, callback){
    fs.readdir(filedir, (err,dir) => {
        callback(dir)
    })
}