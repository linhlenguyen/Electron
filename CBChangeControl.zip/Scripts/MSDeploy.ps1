Param([string]$appPath, [string]$serverName, [string]$username, [string]$password)

msdeploy -verb:sync 
-source:iisApp=$appPath 
-dest:iisApp="Default Web Site",package=$serverURL,ComputerName=$serverName,UserName=$username,Password=$password,AuthType='Basic'
