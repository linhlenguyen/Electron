Param([string]$appPath, [string]$serverName, [string]$username, [string]$password)
